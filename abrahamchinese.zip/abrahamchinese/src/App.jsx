import { useState, useMemo, useEffect } from "react";

// ─── COULEURS ─────────────────────────────────────────────────────────────────
const BG    = "#0A0A12";
const SURF  = "#12121C";
const CARD  = "#1A1A28";
const BORD  = "#252535";
const TEXT  = "#EEEAF0";
const MUTED = "#60607A";
const FAINT = "#1F1F2E";
const GOLD  = "#E9B84C";
const GREEN = "#2ED98A";
const RED   = "#E85C5C";
const BLUE  = "#5BA8E8";
const PURP  = "#9B6BDE";
const ORAN  = "#E89A4C";

const STATUS = {
  attente_fournisseur: { label:"Fournisseur", color:PURP,  bg:"rgba(155,107,222,0.1)" },
  en_attente:          { label:"À envoyer",   color:ORAN,  bg:"rgba(232,154,76,0.1)"  },
  expedie:             { label:"En transit",  color:BLUE,  bg:"rgba(91,168,232,0.1)"  },
  livre:               { label:"Livré",       color:GREEN, bg:"rgba(46,217,138,0.1)"  },
  annule:              { label:"Annulé",      color:RED,   bg:"rgba(232,92,92,0.1)"   },
};

const MOIS_L = ["Jan","Fév","Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc"];
const TRANSPORTEURS = ["DHL","DPD","FedEx"];
const PLATEFORMES   = ["WhatsApp","Instagram","Facebook","Bouche à oreille","Site web","Vinted","LeBonCoin","Autre"];

const MSG = {
  DHL:   (p,T)=>`Bonjour ${p},\nVotre commande est en route !\n${T.length>1?T.map((t,i)=>`Carton ${i+1} : ${t}`).join("\n"):`Suivi : ${T[0]||"[TRACKING]"}`}\nDHL — 6 à 9 jours ouvrés.\nN'hésitez pas à m'envoyer une vidéo à la réception 😊\nAbrahamChinese`,
  DPD:   (p,T)=>`Bonjour ${p},\nVotre commande est en route !\n${T.length>1?T.map((t,i)=>`Carton ${i+1} : ${t}`).join("\n"):`Suivi : ${T[0]||"[TRACKING]"}`}\nDPD → Chronopost — 8 à 15 jours ouvrés.\nN'hésitez pas à m'envoyer une vidéo à la réception 😊\nAbrahamChinese`,
  FedEx: (p,T)=>`Bonjour ${p},\nVotre commande est en route !\n${T.length>1?T.map((t,i)=>`Carton ${i+1} : ${t}`).join("\n"):`Suivi : ${T[0]||"[TRACKING]"}`}\nFedEx — 3 à 7 jours ouvrés.\n⚠️ Des frais de douane peuvent s'appliquer.\nN'hésitez pas à m'envoyer une vidéo à la réception 😊\nAbrahamChinese`,
};

const newArt       = () => ({ id:Date.now()+Math.random(), nom:"", quantite:1, prixAchatCny:"", prixAchat:"", prixVente:"" });
const EMPTY_CLIENT = { id:null, nom:"", tel:"", email:"", ville:"", adresse:"", notes:"" };
const EMPTY_ORDER  = { id:null, clientId:"", articles:[newArt()], statut:"attente_fournisseur", trackings:[""], date:new Date().toISOString().split("T")[0], datePaiementFournisseur:new Date().toISOString().split("T")[0], dateReceptionFournisseur:"", prixTransportCny:"", prixTransport:"", transporteur:"DHL", plateforme:"WhatsApp", notes:"" };

const INIT_CLIENTS = [
  { id:1, nom:"Karim Benali", tel:"0612345678", email:"", ville:"Montpellier", adresse:"12 rue des Acacias", notes:"Client régulier" },
  { id:2, nom:"Mehdi Larbi",  tel:"0698765432", email:"", ville:"Béziers",     adresse:"",                   notes:"" },
];
const INIT_ORDERS = [
  { id:1, clientId:1, statut:"livre",               trackings:["1234567890","1234567891"], date:"2026-01-10", datePaiementFournisseur:"2025-12-20", dateReceptionFournisseur:"2026-01-05", prixTransportCny:"65", prixTransport:"8",  transporteur:"DHL",   plateforme:"WhatsApp",  notes:"", articles:[{id:11,nom:"Montre connectée",quantite:2,prixAchatCny:"120",prixAchat:"15",prixVente:"45"},{id:12,nom:"Chaussures Nike",quantite:3,prixAchatCny:"95",prixAchat:"12",prixVente:"35"}] },
  { id:2, clientId:2, statut:"expedie",             trackings:["0987654321"],              date:"2026-02-20", datePaiementFournisseur:"2026-02-10", dateReceptionFournisseur:"2026-02-18", prixTransportCny:"",   prixTransport:"",   transporteur:"DPD",   plateforme:"Instagram", notes:"Couleur noire", articles:[{id:13,nom:"Écouteurs",quantite:1,prixAchatCny:"64",prixAchat:"8",prixVente:"25"}] },
  { id:3, clientId:1, statut:"attente_fournisseur", trackings:[""],                        date:"2026-03-27", datePaiementFournisseur:"2026-03-27", dateReceptionFournisseur:"",           prixTransportCny:"",   prixTransport:"",   transporteur:"DHL",   plateforme:"WhatsApp",  notes:"", articles:[{id:14,nom:"Claquettes",quantite:20,prixAchatCny:"24",prixAchat:"3",prixVente:"12"},{id:15,nom:"Chaussures Nike",quantite:20,prixAchatCny:"80",prixAchat:"10",prixVente:"30"}] },
  { id:4, clientId:2, statut:"livre",               trackings:["1122334455","1122334456"], date:"2026-03-05", datePaiementFournisseur:"2026-02-20", dateReceptionFournisseur:"2026-03-01", prixTransportCny:"50", prixTransport:"6",  transporteur:"FedEx", plateforme:"WhatsApp",  notes:"", articles:[{id:16,nom:"Sac à dos",quantite:5,prixAchatCny:"80",prixAchat:"10",prixVente:"30"}] },
];

// ─── UTILS ────────────────────────────────────────────────────────────────────
const daysBetween  = (d1,d2) => (!d1||!d2)?null:Math.round((new Date(d2)-new Date(d1))/86400000);
const daysAgo      = d => !d?null:Math.round((Date.now()-new Date(d))/86400000);
const totalVente   = a => a.reduce((s,x)=>s+(parseFloat(x.prixVente)||0)*(parseInt(x.quantite)||1),0);
const totalAchat   = a => a.reduce((s,x)=>s+(parseFloat(x.prixAchat)||0)*(parseInt(x.quantite)||1),0);
const beneficeOrder= o => totalVente(o.articles)-totalAchat(o.articles)-(parseFloat(o.prixTransport)||0);
const getTrackings = o => (o.trackings||[o.tracking||""]).filter(t=>t.trim());

// ─── UI ATOMS ─────────────────────────────────────────────────────────────────
const inp = { width:"100%", background:FAINT, border:`1px solid ${BORD}`, borderRadius:10, padding:"11px 14px", color:TEXT, fontSize:15, outline:"none", boxSizing:"border-box", WebkitAppearance:"none" };
const lbl = { color:MUTED, fontSize:11, fontWeight:700, letterSpacing:1, display:"block", marginBottom:6 };

function F({ label, value, onChange, type="text", placeholder }) {
  return <div style={{marginBottom:14}}>{label&&<label style={lbl}>{label}</label>}<input type={type} value={value??""} placeholder={placeholder} onChange={e=>onChange(e.target.value)} style={inp} /></div>;
}
function S({ label, value, onChange, options }) {
  return <div style={{marginBottom:14}}>{label&&<label style={lbl}>{label}</label>}<select value={value??""} onChange={e=>onChange(e.target.value)} style={inp}>{options.map(o=>typeof o==="string"?<option key={o} value={o}>{o}</option>:<option key={o.value} value={o.value}>{o.label}</option>)}</select></div>;
}

function Badge({ statut }) {
  const st = STATUS[statut]||STATUS.en_attente;
  return <span style={{display:"inline-block", background:st.bg, color:st.color, borderRadius:6, padding:"3px 9px", fontSize:11, fontWeight:700}}>{st.label}</span>;
}

function Pill({ children, color, onClick, active }) {
  return <button onClick={onClick} style={{background:active?color+"22":"transparent", border:`1px solid ${active?color:BORD}`, borderRadius:8, padding:"7px 14px", color:active?color:MUTED, fontWeight:700, fontSize:13, cursor:"pointer", whiteSpace:"nowrap"}}>{children}</button>;
}

function Sheet({ title, onClose, children }) {
  return (
    <div style={{position:"fixed",inset:0,zIndex:300,display:"flex",flexDirection:"column",justifyContent:"flex-end"}}>
      <div onClick={onClose} style={{position:"absolute",inset:0,background:"rgba(0,0,0,0.7)"}} />
      <div style={{position:"relative",background:SURF,borderRadius:"18px 18px 0 0",border:`1px solid ${BORD}`,maxHeight:"93vh",display:"flex",flexDirection:"column"}}>
        <div style={{display:"flex",justifyContent:"center",padding:"12px 0 0"}}><div style={{width:36,height:3,borderRadius:2,background:BORD}} /></div>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 20px"}}>
          <div style={{color:GOLD,fontSize:16,fontWeight:800}}>{title}</div>
          <button onClick={onClose} style={{background:FAINT,border:"none",color:MUTED,fontSize:18,cursor:"pointer",borderRadius:8,width:34,height:34,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
        </div>
        <div style={{overflowY:"auto",padding:"0 20px 50px",flex:1}}>{children}</div>
      </div>
    </div>
  );
}

// ─── MESSAGE ──────────────────────────────────────────────────────────────────
function MessageSheet({ order, client, onClose }) {
  const prenom = client?client.nom.split(" ")[0]:"[Prénom]";
  const trackings = getTrackings(order);
  const msg = (MSG[order.transporteur]||MSG.DHL)(prenom, trackings.length>0?trackings:["[TRACKING]"]);
  const [copied,setCopied] = useState(false);
  return (
    <Sheet title="📨 Message d'expédition" onClose={onClose}>
      <div style={{background:FAINT,borderRadius:12,padding:16,marginBottom:16,fontSize:14,color:"#C8C8D8",lineHeight:1.9,whiteSpace:"pre-line",border:`1px solid ${BORD}`}}>{msg}</div>
      <button onClick={()=>{navigator.clipboard.writeText(msg);setCopied(true);setTimeout(()=>setCopied(false),2500);}}
        style={{width:"100%",background:copied?GREEN+"22":`linear-gradient(135deg,${GOLD},#C89030)`,border:copied?`1px solid ${GREEN}`:"none",borderRadius:10,padding:"13px",color:copied?GREEN:BG,fontWeight:800,fontSize:15,cursor:"pointer"}}>
        {copied?"✓ Copié !":"📋 Copier le message"}
      </button>
    </Sheet>
  );
}

// ─── FORMULAIRE CLIENT ────────────────────────────────────────────────────────
function ClientForm({ initial, onSave, onClose }) {
  const [f,setF] = useState(initial||EMPTY_CLIENT);
  const s=k=>v=>setF(p=>({...p,[k]:v}));
  return (
    <>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        <F label="NOM *"     value={f.nom} onChange={s("nom")} placeholder="Karim Benali" />
        <F label="TÉLÉPHONE *" value={f.tel} onChange={s("tel")} placeholder="06..." type="tel" />
      </div>
      <F label="EMAIL"   value={f.email}   onChange={s("email")}   placeholder="client@mail.com" type="email" />
      <F label="VILLE"   value={f.ville}   onChange={s("ville")}   placeholder="Montpellier" />
      <F label="ADRESSE" value={f.adresse} onChange={s("adresse")} placeholder="12 rue des Acacias" />
      <div style={{marginBottom:14}}><label style={lbl}>NOTES</label><textarea value={f.notes} onChange={e=>s("notes")(e.target.value)} rows={2} style={{...inp,resize:"vertical"}} /></div>
      <div style={{display:"flex",gap:10}}>
        <button onClick={onClose} style={{flex:1,background:"transparent",border:`1px solid ${BORD}`,borderRadius:10,padding:"12px",color:MUTED,fontWeight:700,cursor:"pointer"}}>Annuler</button>
        <button onClick={()=>{if(!f.nom){alert("Nom requis");return;}if(!f.tel){alert("Téléphone requis");return;}onSave({...f,id:f.id||Date.now()});}} style={{flex:2,background:`linear-gradient(135deg,${GOLD},#C89030)`,border:"none",borderRadius:10,padding:"12px",color:BG,fontWeight:800,cursor:"pointer",fontSize:15}}>Sauvegarder</button>
      </div>
    </>
  );
}

// ─── FORMULAIRE COMMANDE ──────────────────────────────────────────────────────
function OrderForm({ initial, clients, taux, onSave, onAddClient, onClose }) {
  const init = initial?{...initial,articles:initial.articles||[newArt()],trackings:initial.trackings||(initial.tracking?[initial.tracking]:[""])}:{...EMPTY_ORDER,articles:[newArt()],trackings:[""]};
  const [f,setF]           = useState(init);
  const [ajout,setAjout]   = useState(false);
  const [nc,setNc]         = useState({nom:"",tel:"",ville:"",adresse:""});
  const [erreur,setErreur] = useState("");
  const s=k=>v=>setF(p=>({...p,[k]:v}));
  const c2u = yuan=>yuan&&taux?(parseFloat(yuan)/taux).toFixed(2):"";
  const c2t = (yuan,q)=>yuan&&taux?((parseFloat(yuan)||0)*(parseInt(q)||1)/taux).toFixed(2):"";

  const setArt=(id,key,val)=>setF(p=>({...p,articles:p.articles.map(a=>{
    if(a.id!==id)return a;
    if(key==="prixAchatCny")return{...a,prixAchatCny:val,prixAchat:c2u(val)};
    return{...a,[key]:val};
  })}));
  const addArt=()=>setF(p=>({...p,articles:[...p.articles,newArt()]}));
  const delArt=id=>setF(p=>({...p,articles:p.articles.filter(a=>a.id!==id)}));

  const setTk=(i,v)=>setF(p=>({...p,trackings:p.trackings.map((t,idx)=>idx===i?v:t)}));
  const addTk=()=>setF(p=>({...p,trackings:[...p.trackings,""]}));
  const delTk=i=>setF(p=>({...p,trackings:p.trackings.filter((_,idx)=>idx!==i)}));

  const transpEur = f.prixTransportCny?c2u(f.prixTransportCny):(f.prixTransport||"");
  const vente=totalVente(f.articles), achat=totalAchat(f.articles);
  const ben=vente-achat-(parseFloat(transpEur)||0);
  const delais=daysBetween(f.datePaiementFournisseur,f.dateReceptionFournisseur);
  const attente=!f.dateReceptionFournisseur&&f.datePaiementFournisseur?daysAgo(f.datePaiementFournisseur):null;

  const save=()=>{
    if(!f.clientId){setErreur("Sélectionne un client.");return;}
    setErreur("");
    onSave({...f,prixTransport:transpEur||f.prixTransport||"",id:f.id||Date.now()});
  };
  const creerClient=()=>{
    if(!nc.nom||!nc.tel){alert("Nom et téléphone requis.");return;}
    const n={...EMPTY_CLIENT,...nc,id:Date.now()};
    onAddClient(n);setF(p=>({...p,clientId:n.id}));setAjout(false);setNc({nom:"",tel:"",ville:"",adresse:""});
  };

  return (
    <>
      {/* Taux */}
      <div style={{background:GOLD+"11",border:`1px solid ${GOLD}33`,borderRadius:10,padding:"9px 14px",marginBottom:16,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{color:MUTED,fontSize:13}}>💱 Taux du jour</span>
        <span style={{color:GOLD,fontWeight:800,fontSize:14}}>1 € = ¥{taux}</span>
      </div>

      {/* Client */}
      <div style={{marginBottom:16}}>
        <label style={lbl}>CLIENT *</label>
        <div style={{display:"flex",gap:8}}>
          <select value={f.clientId??""} onChange={e=>s("clientId")(e.target.value)} style={{...inp,flex:1}}>
            <option value="">— Choisir un client —</option>
            {clients.map(c=><option key={c.id} value={c.id}>{c.nom} · {c.tel}</option>)}
          </select>
          <button onClick={()=>setAjout(v=>!v)} style={{background:GOLD,border:"none",borderRadius:10,padding:"0 16px",color:BG,fontWeight:900,fontSize:20,cursor:"pointer"}}>+</button>
        </div>
        {ajout&&(
          <div style={{background:FAINT,border:`1px solid ${BORD}`,borderRadius:12,padding:14,marginTop:10}}>
            <div style={{color:GOLD,fontWeight:700,fontSize:13,marginBottom:12}}>➕ Nouveau client</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <div><label style={{...lbl,fontSize:10}}>NOM *</label><input value={nc.nom} placeholder="Karim" onChange={e=>setNc(p=>({...p,nom:e.target.value}))} style={inp} /></div>
              <div><label style={{...lbl,fontSize:10}}>TÉL *</label><input value={nc.tel} placeholder="06..." type="tel" onChange={e=>setNc(p=>({...p,tel:e.target.value}))} style={inp} /></div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginTop:8}}>
              <div><label style={{...lbl,fontSize:10}}>VILLE</label><input value={nc.ville} placeholder="Montpellier" onChange={e=>setNc(p=>({...p,ville:e.target.value}))} style={inp} /></div>
              <div><label style={{...lbl,fontSize:10}}>ADRESSE</label><input value={nc.adresse} placeholder="12 rue..." onChange={e=>setNc(p=>({...p,adresse:e.target.value}))} style={inp} /></div>
            </div>
            <div style={{display:"flex",gap:8,marginTop:12}}>
              <button onClick={()=>setAjout(false)} style={{flex:1,background:"transparent",border:`1px solid ${BORD}`,borderRadius:10,padding:"10px",color:MUTED,fontWeight:700,cursor:"pointer"}}>Annuler</button>
              <button onClick={creerClient} style={{flex:2,background:GOLD,border:"none",borderRadius:10,padding:"10px",color:BG,fontWeight:800,cursor:"pointer"}}>✓ Créer</button>
            </div>
          </div>
        )}
      </div>

      {/* Articles */}
      <label style={lbl}>ARTICLES</label>
      <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:10}}>
        {f.articles.map((a,i)=>{
          const q=parseInt(a.quantite)||1;
          return (
            <div key={a.id} style={{background:FAINT,border:`1px solid ${BORD}`,borderRadius:12,padding:14}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                <span style={{color:MUTED,fontSize:11,fontWeight:700}}>ARTICLE {i+1}</span>
                {f.articles.length>1&&<button onClick={()=>delArt(a.id)} style={{background:"none",border:"none",color:RED,fontSize:18,cursor:"pointer"}}>×</button>}
              </div>
              <input value={a.nom} placeholder="Nom de l'article" onChange={e=>setArt(a.id,"nom",e.target.value)} style={{...inp,marginBottom:10}} />
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:8}}>
                <div><label style={{...lbl,fontSize:10}}>QUANTITÉ</label><input type="number" value={a.quantite} min="1" onChange={e=>setArt(a.id,"quantite",e.target.value)} style={inp} /></div>
                <div><label style={{...lbl,fontSize:10}}>VENTE / unité (€)</label><input type="number" value={a.prixVente} placeholder="0" onChange={e=>setArt(a.id,"prixVente",e.target.value)} style={inp} /></div>
              </div>
              {/* Multiplication vente */}
              {a.prixVente&&(
                <div style={{background:GOLD+"11",borderRadius:8,padding:"8px 12px",marginBottom:10,display:"flex",justifyContent:"space-between"}}>
                  <span style={{color:MUTED,fontSize:12}}>{q} × {parseFloat(a.prixVente).toFixed(2)} €</span>
                  <span style={{color:GOLD,fontWeight:800}}>{((parseFloat(a.prixVente)||0)*q).toFixed(2)} €</span>
                </div>
              )}
              {/* Achat fournisseur CNY */}
              <div style={{background:PURP+"0D",border:`1px solid ${PURP}22`,borderRadius:8,padding:"10px 12px"}}>
                <label style={{...lbl,fontSize:10,color:PURP}}>ACHAT FOURNISSEUR</label>
                <div style={{display:"grid",gridTemplateColumns:"1fr auto 1fr",gap:8,alignItems:"flex-end"}}>
                  <div><label style={{...lbl,fontSize:9}}>YUAN / unité (¥)</label><input type="number" value={a.prixAchatCny||""} placeholder="0" onChange={e=>setArt(a.id,"prixAchatCny",e.target.value)} style={{...inp,borderColor:PURP+"33"}} /></div>
                  <div style={{color:PURP,fontSize:16,fontWeight:900,paddingBottom:12}}>→</div>
                  <div><label style={{...lbl,fontSize:9}}>EURO / unité</label>
                    <div style={{...inp,color:GREEN,fontWeight:700,background:GREEN+"0D",borderColor:GREEN+"22"}}>
                      {a.prixAchatCny?`${c2u(a.prixAchatCny)} €`:<span style={{color:BORD}}>0 €</span>}
                    </div>
                  </div>
                </div>
                {a.prixAchatCny&&q>1&&(
                  <div style={{marginTop:6,display:"flex",justifyContent:"space-between",fontSize:12}}>
                    <span style={{color:MUTED}}>{q} × ¥{a.prixAchatCny} = ¥{((parseFloat(a.prixAchatCny)||0)*q).toFixed(0)}</span>
                    <span style={{color:GREEN,fontWeight:700}}>= {c2t(a.prixAchatCny,q)} €</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
      <button onClick={addArt} style={{width:"100%",background:"transparent",border:`1px dashed ${GOLD}44`,borderRadius:10,padding:"11px",color:GOLD,fontWeight:700,fontSize:14,cursor:"pointer",marginBottom:16}}>+ Ajouter un article</button>

      {/* Numéros de suivi multi-cartons */}
      <label style={lbl}>📦 NUMÉROS DE SUIVI</label>
      <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:8}}>
        {f.trackings.map((t,i)=>(
          <div key={i} style={{display:"flex",gap:8,alignItems:"center"}}>
            <span style={{background:FAINT,border:`1px solid ${BORD}`,borderRadius:8,padding:"9px 12px",color:MUTED,fontSize:12,fontWeight:700,whiteSpace:"nowrap"}}>Carton {i+1}</span>
            <input value={t} placeholder="Ex: 1234567890" onChange={e=>setTk(i,e.target.value)} style={{...inp,flex:1,fontFamily:"monospace"}} />
            {f.trackings.length>1&&<button onClick={()=>delTk(i)} style={{background:"none",border:"none",color:RED,fontSize:18,cursor:"pointer"}}>×</button>}
          </div>
        ))}
      </div>
      <button onClick={addTk} style={{width:"100%",background:"transparent",border:`1px dashed ${BLUE}44`,borderRadius:10,padding:"10px",color:BLUE,fontWeight:700,fontSize:13,cursor:"pointer",marginBottom:16}}>+ Ajouter un carton</button>

      {/* Transport CNY → EUR */}
      <div style={{background:BLUE+"0D",border:`1px solid ${BLUE}22`,borderRadius:12,padding:14,marginBottom:14}}>
        <label style={{...lbl,color:BLUE}}>🚚 TRANSPORT (optionnel)</label>
        <div style={{display:"grid",gridTemplateColumns:"1fr auto 1fr",gap:8,alignItems:"flex-end"}}>
          <div><label style={{...lbl,fontSize:9}}>YUAN (¥)</label><input type="number" value={f.prixTransportCny||""} placeholder="0" onChange={e=>s("prixTransportCny")(e.target.value)} style={{...inp,borderColor:BLUE+"33"}} /></div>
          <div style={{color:BLUE,fontSize:16,fontWeight:900,paddingBottom:12}}>→</div>
          <div><label style={{...lbl,fontSize:9}}>EURO (€)</label>
            <div style={{...inp,color:BLUE,fontWeight:700,background:BLUE+"0D",borderColor:BLUE+"22"}}>
              {transpEur?`${transpEur} €`:<span style={{color:BORD}}>0 €</span>}
            </div>
          </div>
        </div>
      </div>

      {/* Récapitulatif finances */}
      {(vente>0||achat>0)&&(
        <div style={{background:FAINT,border:`1px solid ${BORD}`,borderRadius:12,padding:14,marginBottom:14}}>
          <label style={lbl}>💰 RÉCAPITULATIF</label>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:4}}><span style={{color:MUTED}}>Total vente</span><span style={{color:GOLD,fontWeight:700}}>{vente.toFixed(2)} €</span></div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:4}}><span style={{color:MUTED}}>Total achat</span><span style={{color:TEXT,fontWeight:700}}>- {achat.toFixed(2)} €</span></div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:13,marginBottom:10}}><span style={{color:MUTED}}>Transport</span><span style={{color:BLUE,fontWeight:700}}>- {transpEur||"0"} €</span></div>
          <div style={{borderTop:`1px solid ${BORD}`,paddingTop:10,display:"flex",justifyContent:"space-between"}}>
            <span style={{fontWeight:800,color:TEXT}}>Bénéfice net</span>
            <span style={{fontWeight:900,fontSize:20,color:ben>=0?GREEN:RED}}>{ben.toFixed(2)} €</span>
          </div>
          {!transpEur&&<div style={{fontSize:11,color:MUTED,marginTop:4}}>* Transport non renseigné</div>}
        </div>
      )}

      {/* Fournisseur */}
      <div style={{background:PURP+"0D",border:`1px solid ${PURP}22`,borderRadius:12,padding:14,marginBottom:14}}>
        <label style={{...lbl,color:PURP}}>🏭 FOURNISSEUR</label>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
          <F label="DATE PAIEMENT"  value={f.datePaiementFournisseur}  onChange={s("datePaiementFournisseur")}  type="date" />
          <F label="DATE RÉCEPTION" value={f.dateReceptionFournisseur} onChange={s("dateReceptionFournisseur")} type="date" />
        </div>
        {delais !==null&&<div style={{fontSize:13,color:PURP,fontWeight:700,marginTop:-6,marginBottom:6}}>⏱ Délai : {delais} jours</div>}
        {attente!==null&&<div style={{fontSize:13,color:ORAN,fontWeight:700,marginTop:-6,marginBottom:6}}>⏳ En attente depuis {attente} jour{attente>1?"s":""}</div>}
      </div>

      {/* Expédition */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        <S label="STATUT"       value={f.statut}       onChange={s("statut")}       options={Object.entries(STATUS).map(([k,v])=>({value:k,label:v.label}))} />
        <S label="TRANSPORTEUR" value={f.transporteur} onChange={s("transporteur")} options={TRANSPORTEURS} />
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        <F label="DATE"       value={f.date}       onChange={s("date")}       type="date" />
        <S label="PLATEFORME" value={f.plateforme} onChange={s("plateforme")} options={PLATEFORMES} />
      </div>
      <div style={{marginBottom:14}}><label style={lbl}>NOTES</label><textarea value={f.notes} onChange={e=>s("notes")(e.target.value)} rows={2} style={{...inp,resize:"vertical"}} /></div>

      {erreur&&<div style={{background:RED+"11",border:`1px solid ${RED}33`,borderRadius:10,padding:"10px 14px",marginBottom:12,color:RED,fontSize:13,fontWeight:600}}>⚠️ {erreur}</div>}
      <div style={{display:"flex",gap:10}}>
        <button onClick={onClose} style={{flex:1,background:"transparent",border:`1px solid ${BORD}`,borderRadius:10,padding:"12px",color:MUTED,fontWeight:700,cursor:"pointer"}}>Annuler</button>
        <button onClick={save} style={{flex:2,background:`linear-gradient(135deg,${GOLD},#C89030)`,border:"none",borderRadius:10,padding:"12px",color:BG,fontWeight:800,fontSize:15,cursor:"pointer"}}>Sauvegarder</button>
      </div>
    </>
  );
}

// ─── CONVERTISSEUR ────────────────────────────────────────────────────────────
function Convertisseur({ taux }) {
  const [sens,setSens]=useState("CNY_EUR");
  const [val,setVal]=useState("");
  const result=val?(sens==="CNY_EUR"?`${(parseFloat(val)/taux).toFixed(2)} €`:`${(parseFloat(val)*taux).toFixed(2)} ¥`):"";
  return (
    <div>
      <div style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:16,padding:24,textAlign:"center",marginBottom:14}}>
        <div style={{color:MUTED,fontSize:11,fontWeight:700,letterSpacing:1,marginBottom:10}}>TAUX DU JOUR</div>
        <div style={{fontSize:34,fontWeight:900,color:GOLD}}>1 € = ¥{taux}</div>
        <div style={{fontSize:13,color:MUTED,marginTop:6}}>1 ¥ = {(1/taux).toFixed(4)} €</div>
      </div>
      <div style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:16,padding:18}}>
        <div style={{display:"flex",gap:8,marginBottom:16}}>
          {[["CNY_EUR","¥ Yuan → € Euro"],["EUR_CNY","€ Euro → ¥ Yuan"]].map(([sv,l])=>(
            <button key={sv} onClick={()=>{setSens(sv);setVal("");}} style={{flex:1,padding:"10px",borderRadius:10,fontWeight:700,fontSize:13,cursor:"pointer",border:`1px solid ${sens===sv?GOLD:BORD}`,background:sens===sv?GOLD+"22":"transparent",color:sens===sv?GOLD:MUTED}}>{l}</button>
          ))}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr auto 1fr",gap:10,alignItems:"center"}}>
          <div><label style={lbl}>{sens==="CNY_EUR"?"YUAN (¥)":"EURO (€)"}</label><input type="number" value={val} placeholder="0" onChange={e=>setVal(e.target.value)} style={inp} /></div>
          <div style={{color:GOLD,fontSize:20,fontWeight:900,paddingTop:18}}>→</div>
          <div><label style={lbl}>{sens==="CNY_EUR"?"EURO (€)":"YUAN (¥)"}</label><div style={{...inp,color:GOLD,fontWeight:800,background:GOLD+"11",borderColor:GOLD+"33"}}>{result||<span style={{color:BORD}}>0</span>}</div></div>
        </div>
      </div>
    </div>
  );
}

// ─── STATS ────────────────────────────────────────────────────────────────────
function Stats({ orders }) {
  const annees=[...new Set(orders.map(o=>o.date?.split("-")[0]).filter(Boolean))].sort((a,b)=>b-a);
  const defaut=annees.find(a=>orders.some(o=>o.statut==="livre"&&o.date?.startsWith(a)))||String(new Date().getFullYear());
  const [annee,setAnnee]=useState(parseInt(defaut));
  const cmd=orders.filter(o=>o.statut==="livre"&&o.date?.startsWith(String(annee)));
  const parMois=Array.from({length:12},(_,i)=>{
    const m=String(i+1).padStart(2,"0");
    const c=cmd.filter(o=>o.date?.substring(5,7)===m);
    return {mois:MOIS_L[i],ca:c.reduce((s,o)=>s+totalVente(o.articles),0),ben:c.reduce((s,o)=>s+beneficeOrder(o),0),nb:c.length};
  });
  const CA=cmd.reduce((s,o)=>s+totalVente(o.articles),0);
  const BEN=cmd.reduce((s,o)=>s+beneficeOrder(o),0);
  const maxCA=Math.max(...parMois.map(m=>m.ca),1);
  return (
    <div>
      {/* Sélecteur année */}
      <div style={{display:"flex",gap:8,marginBottom:18,flexWrap:"wrap"}}>
        {(annees.length?annees:[String(new Date().getFullYear())]).map(a=>(
          <Pill key={a} color={GOLD} active={annee===parseInt(a)} onClick={()=>setAnnee(parseInt(a))}>{a}</Pill>
        ))}
      </div>
      {/* Totaux */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:18}}>
        {[{label:"Livrées",val:cmd.length,c:GOLD},{label:"CA",val:`${CA.toFixed(0)} €`,c:GOLD},{label:"Bénéfice",val:`${BEN.toFixed(0)} €`,c:BEN>=0?GREEN:RED}].map(({label,val,c})=>(
          <div key={label} style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:12,padding:"14px 12px",textAlign:"center"}}>
            <div style={{fontSize:20,fontWeight:900,color:c}}>{val}</div>
            <div style={{color:MUTED,fontSize:11,fontWeight:700,marginTop:4}}>{label.toUpperCase()}</div>
          </div>
        ))}
      </div>
      {/* Graphique */}
      <div style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:16,padding:18,marginBottom:14}}>
        <div style={{color:MUTED,fontSize:11,fontWeight:700,letterSpacing:1,marginBottom:16}}>PAR MOIS — {annee}</div>
        <div style={{display:"flex",gap:3,alignItems:"flex-end",height:110}}>
          {parMois.map(({mois,ca,ben})=>{
            const hCA=ca>0?Math.max((ca/maxCA)*100,4):0;
            const hBen=ben>0?Math.max((ben/maxCA)*100,4):0;
            return (<div key={mois} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
              <div style={{width:"100%",display:"flex",gap:1,alignItems:"flex-end",height:96}}>
                <div style={{flex:1,background:GOLD,borderRadius:"3px 3px 0 0",height:`${hCA}%`,minHeight:hCA>0?3:0,opacity:0.8}} />
                <div style={{flex:1,background:GREEN,borderRadius:"3px 3px 0 0",height:`${hBen}%`,minHeight:hBen>0?3:0,opacity:0.8}} />
              </div>
              <div style={{color:MUTED,fontSize:8,fontWeight:700}}>{mois}</div>
            </div>);
          })}
        </div>
        <div style={{display:"flex",gap:14,marginTop:10}}>
          <div style={{display:"flex",alignItems:"center",gap:5}}><div style={{width:10,height:10,background:GOLD,borderRadius:2,opacity:0.8}} /><span style={{color:MUTED,fontSize:11}}>CA</span></div>
          <div style={{display:"flex",alignItems:"center",gap:5}}><div style={{width:10,height:10,background:GREEN,borderRadius:2,opacity:0.8}} /><span style={{color:MUTED,fontSize:11}}>Bénéfice</span></div>
        </div>
      </div>
      {/* Tableau */}
      <div style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:16,overflow:"hidden"}}>
        <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",background:SURF,padding:"10px 16px",borderBottom:`1px solid ${BORD}`}}>
          {["Mois","Cmds","CA","Bénéfice"].map(h=><div key={h} style={{color:MUTED,fontSize:11,fontWeight:700}}>{h}</div>)}
        </div>
        {parMois.map(({mois,ca,ben,nb},i)=>(
          <div key={mois} style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",padding:"10px 16px",borderBottom:i<11?`1px solid ${SURF}`:""}} >
            <div style={{color:nb>0?TEXT:MUTED,fontWeight:nb>0?600:400,fontSize:13}}>{mois}</div>
            <div style={{color:nb>0?GOLD:MUTED,fontWeight:700,fontSize:13}}>{nb>0?nb:"—"}</div>
            <div style={{color:nb>0?GOLD:MUTED,fontWeight:700,fontSize:13}}>{nb>0?`${ca.toFixed(0)} €`:"—"}</div>
            <div style={{color:nb>0?(ben>=0?GREEN:RED):MUTED,fontWeight:700,fontSize:13}}>{nb>0?`${ben.toFixed(0)} €`:"—"}</div>
          </div>
        ))}
        <div style={{display:"grid",gridTemplateColumns:"2fr 1fr 1fr 1fr",padding:"12px 16px",background:SURF,borderTop:`1px solid ${BORD}`}}>
          <div style={{color:TEXT,fontWeight:800,fontSize:13}}>TOTAL</div>
          <div style={{color:GOLD,fontWeight:800,fontSize:13}}>{cmd.length}</div>
          <div style={{color:GOLD,fontWeight:800,fontSize:13}}>{CA.toFixed(0)} €</div>
          <div style={{color:BEN>=0?GREEN:RED,fontWeight:800,fontSize:13}}>{BEN.toFixed(0)} €</div>
        </div>
      </div>
    </div>
  );
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [tab,setTab]             = useState("dashboard");
  const [clients,setClients]     = useState(()=>{try{const s=localStorage.getItem("ac_clients");return s?JSON.parse(s):INIT_CLIENTS;}catch{return INIT_CLIENTS;}});
  const [orders,setOrders]       = useState(()=>{try{const s=localStorage.getItem("ac_orders"); return s?JSON.parse(s):INIT_ORDERS; }catch{return INIT_ORDERS;}});
  const [search,setSearch]       = useState("");
  const [filterSt,setFilterSt]   = useState("tous");
  const [filtreEC,setFiltreEC]   = useState(null);
  const [sheet,setSheet]         = useState(null);
  const [msgOrder,setMsgOrder]   = useState(null);
  const [taux,setTaux]           = useState(7.97);

  useEffect(()=>{try{localStorage.setItem("ac_clients",JSON.stringify(clients));}catch{}},[clients]);
  useEffect(()=>{try{localStorage.setItem("ac_orders", JSON.stringify(orders)); }catch{}},[orders]);
  useEffect(()=>{fetch("https://api.frankfurter.app/latest?from=EUR&to=CNY").then(r=>r.json()).then(d=>{if(d?.rates?.CNY)setTaux(parseFloat(d.rates.CNY.toFixed(4)));}).catch(()=>{});},[]);

  const getClient  = id=>clients.find(c=>c.id===parseInt(id));
  const saveOrder  = f=>{setOrders(o=>orders.find(x=>x.id===f.id)?o.map(x=>x.id===f.id?f:x):[...o,f]);setSheet(null);};
  const saveClient = f=>{setClients(c=>clients.find(x=>x.id===f.id)?c.map(x=>x.id===f.id?f:x):[...c,f]);setSheet(null);};
  const delOrder   = id=>setOrders(o=>o.filter(x=>x.id!==id));
  const delClient  = id=>setClients(c=>c.filter(x=>x.id!==id));
  const marquerLivre=id=>setOrders(o=>o.map(x=>x.id===id?{...x,statut:"livre"}:x));
  const addClient  = c=>setClients(cl=>[...cl,c]);

  const enCours  =useMemo(()=>orders.filter(o=>["attente_fournisseur","en_attente","expedie"].includes(o.statut)).sort((a,b)=>({attente_fournisseur:0,en_attente:1,expedie:2}[a.statut]||9)-({attente_fournisseur:0,en_attente:1,expedie:2}[b.statut]||9)),[orders]);
  const finalises=useMemo(()=>orders.filter(o=>["livre","annule"].includes(o.statut)).sort((a,b)=>new Date(b.date)-new Date(a.date)),[orders]);
  const filteredOrders=useMemo(()=>orders.filter(o=>{
    const cl=getClient(o.clientId);const q=search.toLowerCase();
    const m=!search||(cl?.nom||"").toLowerCase().includes(q)||(cl?.tel||"").includes(search)||o.articles.some(a=>a.nom.toLowerCase().includes(q))||getTrackings(o).some(t=>t.includes(search));
    return m&&(filterSt==="tous"||o.statut===filterSt);
  }),[orders,clients,search,filterSt]);

  const TABS=[["dashboard","🏠"],["en_cours","🔥"],["commandes","📦"],["finalises","✅"],["stats","📊"],["clients","👥"],["convertisseur","💱"]];
  const LABELS={dashboard:"Accueil",en_cours:"En cours",commandes:"Toutes",finalises:"Finalisées",stats:"Stats",clients:"Clients",convertisseur:"Taux"};

  // ── CARTE COMMANDE ──────────────────────────────────────────────────────────
  const CarteCommande=({order,showLivre=false})=>{
    const cl        = getClient(order.clientId);
    const vente     = totalVente(order.articles);
    const achat     = totalAchat(order.articles);
    const hasTransp = !!(order.prixTransport&&parseFloat(order.prixTransport)>0);
    const trackings = getTrackings(order);
    const [tv,setTv]   = useState(order.prixTransport||"");
    const [edit,setEdit] = useState(false);
    const tEur = edit?(parseFloat(tv)||0):(parseFloat(order.prixTransport)||0);
    const ben  = vente-achat-tEur;
    const st   = STATUS[order.statut]||STATUS.en_attente;

    return (
      <div style={{background:CARD,border:`1px solid ${BORD}`,borderLeft:`3px solid ${st.color}`,borderRadius:12,overflow:"hidden",marginBottom:10}}>
        {/* Ligne principale */}
        <div style={{padding:"14px 16px",display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:12}}>
          <div style={{flex:1,minWidth:0}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
              <Badge statut={order.statut} />
              <span style={{color:MUTED,fontSize:12}}>📅 {order.date}</span>
            </div>
            <div style={{fontWeight:700,fontSize:15,color:TEXT,marginBottom:2}}>{cl?cl.nom:"—"}</div>
            {cl&&<div style={{color:BLUE,fontSize:13}}>📱 {cl.tel}</div>}
            {/* Articles résumé — max 2 */}
            <div style={{marginTop:8}}>
              {order.articles.slice(0,2).map(a=>(
                <div key={a.id} style={{color:MUTED,fontSize:12,marginBottom:1}}>• {a.nom} <span style={{color:FAINT}}>×{a.quantite}</span></div>
              ))}
              {order.articles.length>2&&<div style={{color:MUTED,fontSize:12}}>+ {order.articles.length-2} autre{order.articles.length-2>1?"s":""}</div>}
            </div>
          </div>
          {/* Prix */}
          <div style={{textAlign:"right",flexShrink:0}}>
            <div style={{fontSize:18,fontWeight:900,color:GOLD}}>{vente.toFixed(0)} €</div>
            <div style={{fontSize:12,fontWeight:700,color:ben>=0?GREEN:RED,marginTop:2}}>
              {ben.toFixed(0)} €{!hasTransp&&!tv?" *":""}
            </div>
            {!hasTransp&&!edit&&<div style={{fontSize:10,color:ORAN,marginTop:2}}>transport ?</div>}
          </div>
        </div>

        {/* Trackings */}
        {trackings.length>0&&(
          <div style={{borderTop:`1px solid ${BORD}`,padding:"8px 16px",display:"flex",flexWrap:"wrap",gap:6}}>
            {trackings.map((t,i)=>(
              <span key={i} style={{background:BLUE+"11",border:`1px solid ${BLUE}22`,borderRadius:6,padding:"3px 8px",color:BLUE,fontFamily:"monospace",fontSize:11}}>
                {trackings.length>1?`C${i+1}: `:""}{t}
              </span>
            ))}
          </div>
        )}

        {/* Transport inline */}
        <div style={{borderTop:`1px solid ${BORD}`,padding:"8px 16px"}}>
          {!edit?(
            <div onClick={()=>setEdit(true)} style={{display:"flex",justifyContent:"space-between",alignItems:"center",cursor:"pointer"}}>
              <span style={{color:hasTransp?BLUE:ORAN,fontSize:13,fontWeight:600}}>🚚 Transport</span>
              <span style={{color:hasTransp?BLUE:ORAN,fontSize:13,fontWeight:700}}>{hasTransp?`${parseFloat(order.prixTransport).toFixed(2)} €`:"Ajouter →"}</span>
            </div>
          ):(
            <div style={{display:"flex",gap:8,alignItems:"center"}}>
              <input type="number" value={tv} placeholder="0.00" autoFocus onChange={e=>setTv(e.target.value)} style={{...inp,flex:1,fontSize:15,fontWeight:700}} />
              <button onClick={()=>{saveOrder({...order,prixTransport:tv});setEdit(false);}} style={{background:GOLD,border:"none",borderRadius:8,padding:"0 14px",height:44,color:BG,fontWeight:800,cursor:"pointer"}}>✓</button>
              <button onClick={()=>{setEdit(false);setTv(order.prixTransport||"");}} style={{background:"transparent",border:`1px solid ${BORD}`,borderRadius:8,padding:"0 12px",height:44,color:MUTED,cursor:"pointer"}}>✕</button>
            </div>
          )}
        </div>

        {/* Actions */}
        <div style={{borderTop:`1px solid ${BORD}`,display:"grid",gridTemplateColumns:"1fr 1fr 1fr"}}>
          <button onClick={()=>setMsgOrder(order)} style={{background:"none",border:"none",borderRight:`1px solid ${BORD}`,color:GREEN,fontWeight:700,fontSize:13,padding:"11px",cursor:"pointer"}}>📨 Message</button>
          <button onClick={()=>setSheet({type:"editOrder",data:order})} style={{background:"none",border:"none",borderRight:`1px solid ${BORD}`,color:MUTED,fontWeight:700,fontSize:13,padding:"11px",cursor:"pointer"}}>✏️ Modifier</button>
          {showLivre
            ?<button onClick={()=>delOrder(order.id)} style={{background:"none",border:"none",color:RED,fontWeight:700,fontSize:13,padding:"11px",cursor:"pointer"}}>🗑</button>
            :<button onClick={()=>marquerLivre(order.id)} style={{background:"none",border:"none",color:GREEN,fontWeight:700,fontSize:13,padding:"11px",cursor:"pointer"}}>✅ Livré</button>
          }
        </div>
      </div>
    );
  };

  return (
    <div style={{minHeight:"100vh",background:BG,color:TEXT,fontFamily:"'SF Pro Display',-apple-system,sans-serif",fontSize:15}}>

      {/* HEADER */}
      <div style={{background:SURF,borderBottom:`1px solid ${BORD}`,padding:"12px 16px",position:"sticky",top:0,zIndex:100}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",maxWidth:680,margin:"0 auto"}}>
          <div>
            <div style={{fontSize:17,fontWeight:800,color:GOLD,letterSpacing:0.3}}>🌏 AbrahamChinese</div>
          </div>
          {(tab==="commandes"||tab==="clients")&&(
            <button onClick={()=>setSheet(tab==="commandes"?{type:"newOrder"}:{type:"newClient"})}
              style={{background:`linear-gradient(135deg,${GOLD},#C89030)`,border:"none",borderRadius:10,padding:"9px 16px",color:BG,fontWeight:800,fontSize:14,cursor:"pointer"}}>
              {tab==="commandes"?"+ Commande":"+ Client"}
            </button>
          )}
        </div>
      </div>

      {/* ONGLETS */}
      <div style={{background:SURF,borderBottom:`1px solid ${BORD}`,overflowX:"auto"}}>
        <div style={{display:"flex",maxWidth:680,margin:"0 auto",padding:"0 4px",minWidth:"max-content"}}>
          {TABS.map(([key,icon])=>(
            <button key={key} onClick={()=>{setTab(key);setSearch("");setFilterSt("tous");setFiltreEC(null);}}
              style={{background:"none",border:"none",borderBottom:tab===key?`2px solid ${GOLD}`:"2px solid transparent",color:tab===key?GOLD:MUTED,fontWeight:tab===key?700:400,fontSize:12,padding:"11px 10px",cursor:"pointer",whiteSpace:"nowrap",transition:"color 0.15s"}}>
              {icon} {LABELS[key]}
            </button>
          ))}
        </div>
      </div>

      <div style={{padding:"16px 16px 100px",maxWidth:680,margin:"0 auto"}}>

        {/* ── DASHBOARD ── */}
        {tab==="dashboard"&&(()=>{
          const aujourd=new Date().toISOString().split("T")[0];
          const moisStr=aujourd.substring(0,7);
          const semDebut=new Date();semDebut.setDate(semDebut.getDate()-((semDebut.getDay()+6)%7));
          const semStr=semDebut.toISOString().split("T")[0];
          const cmdsMois=orders.filter(o=>o.statut==="livre"&&o.date?.startsWith(moisStr));
          const cmdsSemaine=orders.filter(o=>o.statut==="livre"&&o.date>=semStr&&o.date<=aujourd);
          const aEnvoyer=orders.filter(o=>o.statut==="en_attente");
          const enAttFourn=orders.filter(o=>o.statut==="attente_fournisseur");
          const enTransit=orders.filter(o=>o.statut==="expedie");
          const caMois=cmdsMois.reduce((s,o)=>s+totalVente(o.articles),0);
          const benMois=cmdsMois.reduce((s,o)=>s+beneficeOrder(o),0);
          const caSem=cmdsSemaine.reduce((s,o)=>s+totalVente(o.articles),0);
          const sansTransp=orders.filter(o=>["expedie","en_attente"].includes(o.statut)&&!(parseFloat(o.prixTransport)>0));
          const attRetard=enAttFourn.filter(o=>{const d=daysAgo(o.datePaiementFournisseur);return d!==null&&d>=7;});
          const transitLong=enTransit.filter(o=>{const d=daysAgo(o.date);return d!==null&&d>=15;});
          const alertes=[
            aEnvoyer.length>0&&{color:ORAN,titre:"📦 À expédier",desc:`${aEnvoyer.length} commande${aEnvoyer.length>1?"s":""} en attente d'envoi`,nav:()=>{setTab("en_cours");setFiltreEC("en_attente");}},
            sansTransp.length>0&&{color:RED,titre:"⚠️ Transport manquant",desc:`${sansTransp.length} commande${sansTransp.length>1?"s":""} sans prix de transport`,nav:()=>setTab("en_cours")},
            attRetard.length>0&&{color:PURP,titre:"🏭 Fournisseur en retard",desc:`${attRetard.length} commande${attRetard.length>1?"s":""} en attente depuis +7 jours`,nav:()=>{setTab("en_cours");setFiltreEC("attente_fournisseur");}},
            transitLong.length>0&&{color:BLUE,titre:"🚚 Colis long en transit",desc:`${transitLong.length} colis en transit depuis +15 jours`,nav:()=>{setTab("en_cours");setFiltreEC("expedie");}},
          ].filter(Boolean);
          const heure=new Date().getHours();
          return (
            <>
              {/* Salut */}
              <div style={{marginBottom:20}}>
                <div style={{fontSize:20,fontWeight:800,color:TEXT}}>{heure<18?"Bonjour":"Bonsoir"} 👋</div>
                <div style={{color:MUTED,fontSize:13,marginTop:2}}>{new Date().toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long"})}</div>
              </div>

              {/* Alertes ou tout va bien */}
              {alertes.length>0?(
                <div style={{marginBottom:20,display:"flex",flexDirection:"column",gap:8}}>
                  {alertes.map((a,i)=>(
                    <div key={i} onClick={a.nav} style={{background:a.color+"11",border:`1px solid ${a.color}33`,borderLeft:`3px solid ${a.color}`,borderRadius:10,padding:"12px 14px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div>
                        <div style={{color:a.color,fontWeight:700,fontSize:14}}>{a.titre}</div>
                        <div style={{color:MUTED,fontSize:12,marginTop:2}}>{a.desc}</div>
                      </div>
                      <span style={{color:a.color,fontSize:18}}>›</span>
                    </div>
                  ))}
                </div>
              ):(
                <div style={{background:GREEN+"11",border:`1px solid ${GREEN}33`,borderLeft:`3px solid ${GREEN}`,borderRadius:10,padding:"12px 14px",marginBottom:20,display:"flex",alignItems:"center",gap:10}}>
                  <span style={{color:GREEN,fontWeight:700}}>✅ Tout est à jour !</span>
                </div>
              )}

              {/* Stats mois */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
                <div style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:12,padding:"16px 14px"}}>
                  <div style={{color:MUTED,fontSize:10,fontWeight:700,letterSpacing:1}}>CA CE MOIS</div>
                  <div style={{fontSize:24,fontWeight:900,color:GOLD,marginTop:6}}>{caMois.toFixed(0)} €</div>
                  <div style={{color:MUTED,fontSize:12,marginTop:4}}>{cmdsMois.length} livraison{cmdsMois.length!==1?"s":""}</div>
                </div>
                <div style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:12,padding:"16px 14px"}}>
                  <div style={{color:MUTED,fontSize:10,fontWeight:700,letterSpacing:1}}>BÉNÉFICE</div>
                  <div style={{fontSize:24,fontWeight:900,color:benMois>=0?GREEN:RED,marginTop:6}}>{benMois.toFixed(0)} €</div>
                  <div style={{color:MUTED,fontSize:12,marginTop:4}}>Semaine : {caSem.toFixed(0)} €</div>
                </div>
              </div>

              {/* En ce moment */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:20}}>
                {[
                  {icon:"🏭",val:enAttFourn.length,label:"Fournisseur",c:PURP,nav:()=>{setTab("en_cours");setFiltreEC("attente_fournisseur");}},
                  {icon:"📦",val:aEnvoyer.length,  label:"À envoyer",  c:ORAN,nav:()=>{setTab("en_cours");setFiltreEC("en_attente");}},
                  {icon:"🚚",val:enTransit.length,  label:"En transit", c:BLUE,nav:()=>{setTab("en_cours");setFiltreEC("expedie");}},
                ].map(({icon,val,label,c,nav})=>(
                  <div key={label} onClick={nav} style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:12,padding:"14px 10px",textAlign:"center",cursor:"pointer"}}>
                    <div style={{fontSize:20}}>{icon}</div>
                    <div style={{fontSize:22,fontWeight:900,color:c,marginTop:4}}>{val}</div>
                    <div style={{color:MUTED,fontSize:10,fontWeight:700,marginTop:2}}>{label.toUpperCase()}</div>
                  </div>
                ))}
              </div>

              <button onClick={()=>setSheet({type:"newOrder"})} style={{width:"100%",background:`linear-gradient(135deg,${GOLD},#C89030)`,border:"none",borderRadius:12,padding:"15px",color:BG,fontWeight:900,fontSize:16,cursor:"pointer"}}>
                ➕ Nouvelle commande
              </button>
            </>
          );
        })()}

        {/* ── EN COURS ── */}
        {tab==="en_cours"&&(()=>{
          const groupes=[
            {key:"attente_fournisseur",icon:"🏭",titre:"Fournisseur", c:PURP},
            {key:"en_attente",         icon:"📦",titre:"À envoyer",   c:ORAN},
            {key:"expedie",            icon:"🚚",titre:"En transit",   c:BLUE},
          ];
          const filtrees=filtreEC?enCours.filter(o=>o.statut===filtreEC):enCours;
          const gActif=filtreEC?groupes.find(g=>g.key===filtreEC):null;
          return (
            <>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:16}}>
                {groupes.map(g=>{
                  const nb=enCours.filter(o=>o.statut===g.key).length;
                  const actif=filtreEC===g.key;
                  return (
                    <div key={g.key} onClick={()=>setFiltreEC(actif?null:g.key)}
                      style={{background:actif?g.c+"18":CARD,border:`1px solid ${actif?g.c:BORD}`,borderRadius:12,padding:"14px 10px",textAlign:"center",cursor:"pointer",transition:"all 0.15s"}}>
                      <div style={{fontSize:20}}>{g.icon}</div>
                      <div style={{fontSize:22,fontWeight:900,color:g.c,marginTop:4}}>{nb}</div>
                      <div style={{color:actif?g.c:MUTED,fontSize:10,fontWeight:700,marginTop:2}}>{g.titre.toUpperCase()}</div>
                    </div>
                  );
                })}
              </div>
              {gActif&&(
                <div style={{background:gActif.c+"11",border:`1px solid ${gActif.c}33`,borderLeft:`3px solid ${gActif.c}`,borderRadius:10,padding:"10px 14px",marginBottom:14,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <span style={{color:gActif.c,fontWeight:700}}>{gActif.icon} {gActif.titre}</span>
                  <span style={{background:gActif.c,color:BG,borderRadius:20,padding:"2px 10px",fontSize:12,fontWeight:900}}>{filtrees.length}</span>
                </div>
              )}
              {filtrees.length===0
                ?<div style={{textAlign:"center",color:MUTED,padding:50}}><div style={{fontSize:36,marginBottom:10}}>✅</div>{filtreEC?"Aucune commande ici.":"Aucune commande en cours !"}</div>
                :<div>{filtrees.map(o=><CarteCommande key={o.id} order={o} />)}</div>
              }
            </>
          );
        })()}

        {/* ── TOUTES ── */}
        {tab==="commandes"&&(
          <>
            {/* Filtres statut */}
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:12,overflowX:"auto"}}>
              <Pill color={GOLD} active={filterSt==="tous"} onClick={()=>setFilterSt("tous")}>Toutes ({orders.length})</Pill>
              {Object.entries(STATUS).map(([k,v])=>{
                const nb=orders.filter(o=>o.statut===k).length;
                return <Pill key={k} color={v.color} active={filterSt===k} onClick={()=>setFilterSt(filterSt===k?"tous":k)}>{v.label} ({nb})</Pill>;
              })}
            </div>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="🔍  Client, article, suivi..." style={{...inp,marginBottom:14}} />
            {filteredOrders.length===0
              ?<div style={{textAlign:"center",color:MUTED,padding:50}}>Aucune commande.</div>
              :<div>{filteredOrders.map(o=><CarteCommande key={o.id} order={o} showLivre={["livre","annule"].includes(o.statut)} />)}</div>
            }
          </>
        )}

        {/* ── FINALISÉES ── */}
        {tab==="finalises"&&(
          <>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:16}}>
              {[
                {label:"Livrées",      val:finalises.filter(o=>o.statut==="livre").length, c:GREEN},
                {label:"CA total",     val:`${finalises.filter(o=>o.statut==="livre").reduce((s,o)=>s+totalVente(o.articles),0).toFixed(0)} €`, c:GOLD},
                {label:"Bénéfice",     val:`${finalises.filter(o=>o.statut==="livre").reduce((s,o)=>s+beneficeOrder(o),0).toFixed(0)} €`, c:GREEN},
              ].map(({label,val,c})=>(
                <div key={label} style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:12,padding:"14px 10px",textAlign:"center"}}>
                  <div style={{fontSize:18,fontWeight:900,color:c}}>{val}</div>
                  <div style={{color:MUTED,fontSize:10,fontWeight:700,marginTop:4}}>{label.toUpperCase()}</div>
                </div>
              ))}
            </div>
            {finalises.length===0
              ?<div style={{textAlign:"center",color:MUTED,padding:60}}><div style={{fontSize:40,marginBottom:10}}>📭</div>Aucune commande finalisée.</div>
              :<div>{finalises.map(o=><CarteCommande key={o.id} order={o} showLivre />)}</div>
            }
          </>
        )}

        {tab==="stats"       &&<Stats orders={orders} />}
        {tab==="convertisseur"&&<Convertisseur taux={taux} />}

        {/* ── CLIENTS ── */}
        {tab==="clients"&&(
          <>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="🔍  Nom ou téléphone..." style={{...inp,marginBottom:14}} />
            {clients.filter(c=>!search||c.nom.toLowerCase().includes(search.toLowerCase())||c.tel.includes(search)).length===0
              ?<div style={{textAlign:"center",color:MUTED,padding:50}}>Aucun client.</div>
              :clients.filter(c=>!search||c.nom.toLowerCase().includes(search.toLowerCase())||c.tel.includes(search)).map(cl=>{
                const cmds=orders.filter(o=>parseInt(o.clientId)===cl.id);
                const total=cmds.reduce((s,o)=>s+totalVente(o.articles),0);
                return (
                  <div key={cl.id} style={{background:CARD,border:`1px solid ${BORD}`,borderRadius:12,overflow:"hidden",marginBottom:10}}>
                    <div style={{padding:"14px 16px",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                      <div>
                        <div style={{fontWeight:700,fontSize:15,color:TEXT}}>{cl.nom}</div>
                        <div style={{color:BLUE,fontSize:13,marginTop:4}}>📱 {cl.tel}</div>
                        {cl.ville&&<div style={{color:MUTED,fontSize:12,marginTop:2}}>📍 {cl.ville}</div>}
                        {cl.adresse&&<div style={{color:MUTED,fontSize:12,marginTop:1}}>🏠 {cl.adresse}</div>}
                        {cl.notes&&<div style={{color:MUTED,fontSize:12,fontStyle:"italic",marginTop:2}}>{cl.notes}</div>}
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontSize:18,fontWeight:900,color:GOLD}}>{total.toFixed(0)} €</div>
                        <div style={{color:MUTED,fontSize:12,marginTop:2}}>{cmds.length} cmd{cmds.length!==1?"s":""}</div>
                      </div>
                    </div>
                    {cmds.length>0&&(
                      <div style={{borderTop:`1px solid ${BORD}`,padding:"10px 16px"}}>
                        <div style={{color:MUTED,fontSize:10,fontWeight:700,letterSpacing:1,marginBottom:8}}>COMMANDES</div>
                        {cmds.map(o=>(
                          <div key={o.id} style={{background:SURF,borderRadius:8,padding:"9px 12px",marginBottom:6}}>
                            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
                              <Badge statut={o.statut} />
                              <span style={{color:GOLD,fontWeight:700,fontSize:13}}>{totalVente(o.articles).toFixed(0)} €</span>
                            </div>
                            {o.articles.slice(0,2).map(a=><div key={a.id} style={{color:MUTED,fontSize:12}}>• {a.nom} ×{a.quantite}</div>)}
                            {o.articles.length>2&&<div style={{color:MUTED,fontSize:12}}>+ {o.articles.length-2} autre{o.articles.length-2>1?"s":""}</div>}
                            <div style={{color:MUTED,fontSize:11,marginTop:4}}>{o.date} · {o.transporteur}</div>
                            {getTrackings(o).map((t,i)=><div key={i} style={{color:BLUE,fontFamily:"monospace",fontSize:11,marginTop:1}}>📦 {getTrackings(o).length>1?`C${i+1}: `:""}{t}</div>)}
                          </div>
                        ))}
                      </div>
                    )}
                    <div style={{borderTop:`1px solid ${BORD}`,display:"grid",gridTemplateColumns:"1fr 1fr"}}>
                      <button onClick={()=>setSheet({type:"editClient",data:cl})} style={{background:"none",border:"none",borderRight:`1px solid ${BORD}`,color:MUTED,fontWeight:700,fontSize:13,padding:"12px",cursor:"pointer"}}>✏️ Modifier</button>
                      <button onClick={()=>delClient(cl.id)} style={{background:"none",border:"none",color:RED,fontWeight:700,fontSize:13,padding:"12px",cursor:"pointer"}}>🗑 Supprimer</button>
                    </div>
                  </div>
                );
              })
            }
          </>
        )}
      </div>

      {sheet?.type==="newOrder"  &&<Sheet title="➕ Nouvelle commande"    onClose={()=>setSheet(null)}><OrderForm clients={clients} taux={taux} onSave={saveOrder} onAddClient={addClient} onClose={()=>setSheet(null)} /></Sheet>}
      {sheet?.type==="editOrder" &&<Sheet title="✏️ Modifier"             onClose={()=>setSheet(null)}><OrderForm initial={sheet.data} clients={clients} taux={taux} onSave={saveOrder} onAddClient={addClient} onClose={()=>setSheet(null)} /></Sheet>}
      {sheet?.type==="newClient" &&<Sheet title="➕ Nouveau client"        onClose={()=>setSheet(null)}><ClientForm onSave={saveClient} onClose={()=>setSheet(null)} /></Sheet>}
      {sheet?.type==="editClient"&&<Sheet title="✏️ Modifier le client"   onClose={()=>setSheet(null)}><ClientForm initial={sheet.data} onSave={saveClient} onClose={()=>setSheet(null)} /></Sheet>}
      {msgOrder&&<MessageSheet order={msgOrder} client={getClient(msgOrder.clientId)} onClose={()=>setMsgOrder(null)} />}
    </div>
  );
}
